


#define TRUE    1
#define FALSE   0
#define ON      1
#define OFF     0

//***** I/O ***********
sbit PROG   at RA0_bit;
sbit ENTER  at RA1_bit;
sbit UP     at RA2_bit;
sbit DOWN   at RA3_bit;
sbit DIS_1  at RA7_Bit;
sbit DIS_2  at RA6_Bit;

//Configure i/o ports where display is connected
//below is segment data port
//#define SEVENSEG_TRIS   TRISB
//#define SEVENSEG_PORT   PORTB

//below is disp select data port
#define SEVEN_SEG_TRIS  TRISA
#define SEVEN_SEG_PORT  PORTA

/*

*/
void SevenSegInit();
void SevenSegment(unsigned int num);
void SevenSegPrint(unsigned int num);
void SevenSegISR();

int digits[2]={0};
char Dis_Shift;

void main()
{
   //Initialize the Seven Segment Subsystem
   SevenSegInit();
   while(1)
   {
   //Print a number to display
   SevenSegPrint(12);
   //Do nothing, just loop!
   }
}

//Simple Delay Routine
void Wait(unsigned int delay)
{
   for(;delay;delay--)
      Delay_us(100);
}

void SevenSegInit()
{
   //Setup i/o ports
   TRISA = 0x0F;
   TRISB = 0x00;
   CMCON = 0x07;
   PORTA = 0x00;
   PORTB = 0x00;
                //76543210
   OPTION_REG = 0b10000111;     // Prescaler is assigned to the Timer0 module 1:256
                                // PORTB pull-ups are disabled
   GIE_bit  = 1;      // Global Interrupt Enable
   /*
   Setup Timer0
   */
   T0IE_bit = 1;      // TMR0 Overflow Interrupt Enable
   T0IF_bit = 0;
   T0CS_bit = 0;      // TMR0 Internal instruction cycle clock (CLKOUT)
   /*
   Setup Timer1
   */
   TMR1ON_bit = 1;    // Enables Timer1
   TMR1CS_bit = 0;    // Clock Source Internal clock (FOSC/4)
   T1OSCEN_bit = OFF; // Timer1 Oscillator is shut off
   T1CKPS0_bit = 1;   // 1:8 Timer1 Prescale value
   T1CKPS1_bit = 1;
   TMR1L = 0x00;      // Clear Timer1 timer/counter Registers
   TMR1H = 0x00;
}

void SevenSegment(unsigned int num)
{
                //0gfedcba   , seven segment
    int n[] = {0b00111111,  // Zero
               0b00000110,  // One
               0b01011011,  // Two
               0b01001111,  // Three
               0b01100110,  // Four
               0b01101101,  // Five
               0b01111100,  // Six
               0b00000111,  // Seven
               0b01111111,  // Eight
               0b01100111,  // Nine
               0b01110001,  // F
               0b01010100}; // n
               
    SEVEN_SEG_PORT= n[num];
}

void SevenSegPrint(unsigned int num)
{
   /*
   This function breaks apart a given integer into separete digits
   and writes them to the display array i.e. digits[]
   */
   if(num>100)
   {
      digits[0] = num%10;
      digits[1] = num/10;
   }
   else
       {
           digits[0] = 9;
           digits[1] = 9;
       }
}

void SevenSegISR()
{
   /*
   Updates the displays
   */
   Dis_Shift != Dis_Shift;  // Display shift
   RA7_bit = Dis_Shift;   //Activate a display according to Dis_Shift
   RB6_bit = !Dis_Shift;
   SevenSegment(digits[Dis_Shift]);
}

//Main Interrupt Service Routine (ISR)
void interrupt(void)
{
   //Check if it is TMR0 Overflow ISR
   if(T0IF_bit)
   {
      TMR0=150;
      //Call the SevenSegISR
      SevenSegISR();
 //     RA7_bit = 1;
 //     PORTB = 0xff;
      //Clear Flag
      T0IF_bit=0;
   }
}

