
#define TRUE    1
#define FALSE   0
#define ON      1
#define OFF     0

//***** I/O ***********
sbit PROG   at RA0_bit;
sbit ENTER  at RA1_bit;
sbit UP     at RA2_bit;
sbit DOWN   at RA3_bit;
sbit DIS_1  at RA7_Bit;
sbit DIS_2  at RA6_Bit;

//****** flags defines ********
bit Fblink;
bit FProg;

//****** byte Flags ***********
unsigned char CProg, CTProg;    // learn timers and counter
unsigned char CFlash, CTFlash;  // seven segment flashing timer and counter
unsigned char CTime;            // timer counter

//****** global variables *****
int counter, i;
int blink;
unsigned int XTMR;

//--------------------------------------------------------------------
// timings
//
#define TOUT     5    // 5 * 71ms = 350ms output delay
#define TFLASH   500  // 4 * 71ms = 280ms half period
#define TPROG    255  // 255 * 71ms = 18s learn timeout

void Display(int num);
void Timing(void);

void main() 
{
     TRISA = 0x0F;
     TRISB = 0x00;
     CMCON = 0x07;
                  //76543210
     OPTION_REG = 0b10001000;
     GIE_bit  = 1;      // Global Interrupt Enable
     /*
     Timer0
     */
     T0IE_bit = 1;      // TMR0 Overflow Interrupt Enable
     T0IF_bit = 0;
     T0CS_bit = 0;      // TMR0 Internal instruction cycle clock (CLKOUT)
     /*
     Timer1
     */
     TMR1ON_bit = 1;    // Enables Timer1
     TMR1CS_bit = 0;    // Clock Source Internal clock (FOSC/4)
     T1OSCEN_bit = OFF; // Timer1 Oscillator is shut off
     T1CKPS0_bit = 1;   // 1:8 Timer1 Prescale value
     T1CKPS1_bit = 1;
     TMR1L = 0x00;      // Clear Timer1 timer/counter Registers
     TMR1H = 0x00;
     
     PORTA = 0x00;
     PORTB = 0x00;
     
     CTProg = 0;      // Prog debounce
     CProg = 0;       // Prog timer
     CTime = 0;       // timer count
     CFlash = 0;      // flash counter
     CTFlash = 0;     // flash timer
     FProg = FALSE;   // start in normal mode
     XTMR = 0;
     Fblink = 0;
     
     counter = 0;
     blink = 0;
     i = 0;

     // main loop
     while(1)
     {
         Display(i);
         if(i>99) i = 0;
         
         // poll prog
         if ( !Prog) // low -> button pressed
         {
             CProg++;
             // pressing Learn button for more than 3sec -> Enter programing mode
             if (CProg == 30) // 3sec debounce
             {
                 FProg = TRUE; // enter learn mode comand!
                 CFlash = TFLASH;
             }
          }
          else CProg=0; // reset counter

          // Prog Mode timout after 18s (TPROG * 100ms)
          if ( CTProg > 0)
          {
              CTProg--; // count down
              if ( CTProg == 0) // if timed out
              {
                  FProg = FALSE;
              }
          }
          // Seven segment Flashing
          if(FProg)
          {
              if ( CFlash > 0)
              {
                  CTFlash--;             // count down
                  if ( CTFlash == 0)     // if timed out
                  {
                      CTFlash = TFLASH;  // reload timer
                      CFlash--;          // count one flash
                      PORTB = 0x00;      // toggle Seven segment
                      if ( CFlash & 1);
                         PORTB = 0x7F;
                  }
              }
          }
//          if(!Fblink)
//          {
//          if(!DOWN)
//          {

//          }
//          else PORTB = 0x00;

//          RA6_bit = 1;
//          RA7_bit = 1;
//          PORTB = 0xFF;
      } // main loop
} // main

void Timing(void)
{
    if(FProg)
    {

    }
}

void Display(int num)
{
    int temp;
                 //0gfedcba   , seven segment
    int n[16] = {0b00111111,  // Zero
                 0b00000110,  // One
                 0b01011011,  // Two
                 0b01001111,  // Three
                 0b01100110,  // Four
                 0b01101101,  // Five
                 0b01111100,  // Six
                 0b00000111,  // Seven
                 0b01111111,  // Eight
                 0b01100111,  // Nine
                 0b01110001,  // F
                 0b01010100}; // n
                 

  if(num <= 9)
  {
      DIS_1 = ON;
      DIS_2 = OFF;
      PORTB = n[num];
  }
  else
  {
      DIS_1 = ON;
      DIS_2 = OFF;
      PORTB = n[num%10];
      Delay_ms(5);
      DIS_1 = OFF;
      DIS_2 = ON;
      PORTB = n[num/10];
      Delay_ms(5);
  }
}
void interrupt(void)
{
     if (T0IF_bit)
     {
         TMR0 -= 200;
         XTMR++;
         if(++blink==2500)
         {
              blink = 0;
              Fblink ^=1;
         }
         if(++counter == 2500)
         {
              i++;
              counter = 0;
         }
//         else counter++;
          T0IF_bit = 0;
     }
     if(TMR1IF_bit)
     {
     }
}