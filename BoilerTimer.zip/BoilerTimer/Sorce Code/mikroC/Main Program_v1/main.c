
#define TRUE    1
#define FALSE   0
#define ON      1
#define OFF     0

//***** I/O ***********
sbit PROG   at RA0_bit;
sbit ENTER  at RA1_bit;
sbit UP     at RA2_bit;
sbit DOWN   at RA3_bit;
sbit DIS_1  at RA7_Bit;
sbit DIS_2  at RA6_Bit;
//sbit OUT    at RB7_bit;

//****** flags defines ********
bit FBlink, blink;
bit FProg;
bit FKey;

//****** byte Flags ***********
unsigned int CProg, CTProg;    // learn timers and counter
unsigned int CBlink, CTBlink;  // seven segment flashing timer and counter
unsigned int CTime;            // timer counter
unsigned int CKey, CTKey;      // UP DOWN key delay
unsigned char CTMinute;
unsigned char OUT;

//****** global variables *****
unsigned int  count;
unsigned char Second;
signed   char Minute;

//--------------------------------------------------------------------
// timings
//
#define TOUT     5    // 5 * 71ms = 350ms output delay
#define TFLASH   500  // 4 * 71ms = 280ms half period
#define TPROG    255  // 255 * 71ms = 18s learn timeout

void Display(int num);
void Timing(void);
void Init(void);

void main() 
{
     Init();
     
     // main loop
     while(1)
     {
         if(blink) Display(Minute - CTMinute);
         else PORTB = 0x00 | OUT;

         // poll prog
         if (!Prog) // low -> button pressed
         {
             // pressing Learn button for more than 3sec -> Enter programing mode
             if(CTProg > 2)
             {
                 FProg = TRUE;        // enter learn mode comand!
                 FBlink = TRUE;       // update display blinking flag
//                 if(!CProg) CProg++;
             }
             
          }
          else CTProg = 0; // reset counter
         
          if(FProg)
          {
              if(!UP)
              {
                  if(!FKey) Minute++;
                  FKey = 1;
                  if(Minute>99) Minute = 99;
              }
              else if(!Down)
              {
                 if(!FKey) Minute--;
                 FKey = 1;
                 if(Minute<=0) Minute = 0;
              }
              else if(!Enter)
              {
                 if(!FKey)
                 {
                    FProg = OFF;
                    FBlink = ON;       // tern on seven segment display
                    CTMinute = 0;
                    Second = 0;
                    OUT = 0x80;          // tern on output relay
                    TMR1ON_bit = ON;   // Enables Timer1
                    TMR1L = 0x00;      // Clear Timer1 timer/counter Registers
                    TMR1H = 0x00;
                    TMR1IF_bit=0;
                 }
                 FKey = 1;
              }
              else FKey = 0;
          }
          else
          {
              if((Minute - CTMinute)<=0)
              {
                 OUT = 0x00;          // tern off output relay
                 TMR1ON_bit = OFF;    // Disable Timer1
//                 if(CProg) FBlink = ON;
              }
              if(!Enter)
              {
                 FBlink = OFF;
              }
          }
      } // main loop
} // main
/*
 Function : void Display(int num)
 InPut    : number rate 0-65536
 OutPut   : two digit seven segment numbe
*/
void Display(int num)
{
    int temp;
                          //0gfedcba   , seven segment
   unsigned char n[16] = {0b00111111,  // Zero
                          0b00000110,  // One
                          0b01011011,  // Two
                          0b01001111,  // Three
                          0b01100110,  // Four
                          0b01101101,  // Five
                          0b01111100,  // Six
                          0b00000111,  // Seven
                          0b01111111,  // Eight
                          0b01100111,  // Nine
                          0b01110001,  // F
                          0b01010100}; // n
                 

  if(num <= 9)
  {
      DIS_1 = ON;
      DIS_2 = OFF;
      PORTB = n[num] | OUT;
  }
  else
  {
      DIS_1 = ON;
      DIS_2 = OFF;
      PORTB = n[num%10] | OUT;
      Delay_ms(4);
      DIS_1 = OFF;
      DIS_2 = ON;
      PORTB = n[num/10] | OUT;
      Delay_ms(4);
  }
}
void Init(void)
{
     TRISA = 0x0F;      // PORTA I/O defined
     TRISB = 0x00;      // PORTB I/O defined
     CMCON = 0x07;      // Disable comperators
                  //76543210
     OPTION_REG = 0b10001000;
     GIE_bit  = 1;      // Global Interrupt Enable
     /*
     Timer0
     */
     T0IE_bit = 1;      // TMR0 Overflow Interrupt Enable
     T0IF_bit = 0;      // clear timer0 interrupt flag
     T0CS_bit = 0;      // TMR0 Internal instruction cycle clock (CLKOUT)
     /*
     Timer1
     */
     TMR1ON_bit = OFF;   // Disable Timer1
     TMR1CS_bit = 0;     // Clock Source Internal clock (FOSC/4)
     T1OSCEN_bit = OFF;  // Timer1 Oscillator is shut off
     T1CKPS0_bit = 1;    // 1:8 Timer1 Prescale value
     T1CKPS1_bit = 1;
     TMR1L = 0x00;       // Clear Timer1 timer/counter Registers
     TMR1H = 0x00;
     TMR1IF_bit=0;       // clear timer0 interrupt flag

     PORTA = 0x00;      // init porta, display off
     PORTB = 0x00;      // init portb, set output to low

     CTProg = 0;        // Prog debounce
     CProg = 0;         // Prog timer
     CTime = 0;         // timer count
     CBlink = 0;        // flash counter
     CTBlink = 0;       // flash timer
     FProg = FALSE;     // start in normal mode
     FBlink = 0;        // blink Display flag
     blink = 1;         // display on
     Second = 0;        // second counter
     Minute = 0;        // minute variable
     CTMinute = 0;      // minute counter
     CKey = 0;          // key holding counter
     CTKey = 0;         // key timer
     FKey = 0;          // key holding flag
     OUT = 0;           // output variable
     count = 0;         // general counter
}

/*
*/
void interrupt(void)
{
     /*
     timer 0, general use timer to run ivents in real time
     */
     if (T0IF_bit)
     {
         TMR0 -= 200;     // reinit timer0, 200uS
         // speed up down keys
         if(FProg)
         {
             if(!UP||!DOWN)
             {
                 if(++CKey == count)   // key press delay
                 {
                     CKey = 0;
                     FBlink = OFF;
                     FKey = 0;
                     count = 500;      // 250mSec delay
                 }
             }
             else
             {
                 CKey = 0;
                 FBlink = ON;
                 count = 7500;    // 3sec delay
             }
         }
         else count = 7500;       // 3sec delay

         // generate blink period
         if(++CTBlink==2500)    // every one second
         {
             CTProg++;
             CTBlink =0;
             if(FBlink) blink ^= 1;
             else blink = ON;
         }

         T0IF_bit = 0;    // clear timer0 interrup flag
     }
     /*
     timer 1, generate one Second interrupt
     */
     if(TMR1IF_bit)
     {
         TMR1L = 0;   // reloade timer1 counter generate 0.5s
         TMR1H = 0;
         // generate one second period
         if(++CTime > 1)
         {
            CTime = 0;
            if(++Second > 59)  // second count up, seset every 60 second
            {
                Second = 0;
                if(++CTMinute > 99) CTMinute = 0;   // minute count up
            }
         }
         
         TMR1IF_bit = 0;    // clear timer1 interrup flag
     }
}