//
// Program Routine
//
// Time counting programing
// Does Normal Operation and Prog Mode
//
// INPUT: Swthch Kwy
//
// OUTPUT: none
//
void Prog()
{
     if ( FLearn)
     {
     // Learn Mode
 if ( Find()== FALSE)
 // could not find the Serial Number in memory
 {
 if ( !Insert()) // look for new space
 return; // fail if no memory available
 }
 // ASSERT Ind is pointing to a valid memory location
 IDWrite(); // write Serial Number in memory
 FHopOK = TRUE; // enable updating Hopping Code
 HopUpdate(); // Write Hoping code in memory
 CFlash = 32; // request Led flashing
 CTFlash = TFLASH; // load period timer
 Led = TRUE; // start with Led on
 FLearn = FALSE; // terminate successfully Learn
 } // Learn
 else // Normal Mode of operation
 {
 if ( Find()== FALSE)
 return;
 if ( !HopCHK()) // check Hopping code integrity
 return;
 if ( FSame) // identified same code as last memorized
 {
 if ( COut >0) // if output is still active
 COut = TOUT; // reload timer to keep active
 else
 return; // else discard
 }
 else // hopping code incrementing properly
 {? 2001 Microchip Technology Inc. Preliminary DS00744A-page 15
AN744
 HopUpdate(); // update memory
 // set outputs according to function code
 if ( BIT_TEST(Buffer[3],S0))
 Out0 = ON;
 if ( BIT_TEST(Buffer[3],S1))
 Out1 = ON;
 if ( BIT_TEST(Buffer[3],S2))
 Out2 = ON;
 if ( BIT_TEST(Buffer[3],S3))
 Out3 = ON;
 // set low battery flag if necessary
 if ( BIT_TEST(Buffer[8],VFlag))
 Vlow = ON;
 // check against learned function code
 if ( (( Buffer[7] ^ FCode) & 0xf0) == 0)
 Led = ON;

 // init output timer
 COut = TOUT;
 }// recognized
 } // normal mode
} // remote